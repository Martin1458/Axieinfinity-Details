import requests
import json
import os.path
from os import path
from datetime import datetime
import pandas
from openpyxl import load_workbook
import time

tableAxieTransactions = {}
l01 = l02 = l03 = l04 = l05 = l06 = l07 = l08 = l09 = l10 = l11 = l12 = l13 = l14 = l15 = l16 = l17 = l18 = l19 = l20 = l21 = l22 = l23 = l24 = l25 = l26 = l27 = ['']
auction = name = priceUSD = rarity = priceLast = priceQuick = priceReasonable = pricePatient = similarAxies = ''
url = 'https://graphql-gateway.axieinfinity.com/graphql'

priceLink = 'https://www.axie.tech/axie-pricing/'
caps = DesiredCapabilities().CHROME
caps["pageLoadStrategy"] = "normal"
options = webdriver.ChromeOptions()
options.add_argument("headless")
driver = webdriver.Chrome(desired_capabilities=caps, service=Service('C:\webdrivers\chromedriver.exe'), options=options)



#if __name__ == "__main__":
#    for p in range(len(listOfIds)):
#        AxieId = listOfIds[p]
#        AxieDetails()
#    print(f'\033[92mDone!!!\033[0m')

fileNumber = 0
fileName = 'Axies' + str(fileNumber) + '.xlsx'

howManyAxiesPerFile = 5
firstAxieId = 1046
lastAxieId = 1048



if __name__ == "__main__":
    NewId = firstAxieId
    for p in range((lastAxieId-firstAxieId)+1):
        if p % howManyAxiesPerFile == 0:
            fileNumber += 1
            fileName = 'Axies' + str(fileNumber) + '.xlsx'
            print(fileName)

        print(NewId)
        AxieId = NewId
        params = {
            "axieId": AxieId,
            "from": 0,
            "size": 10
        }
        jsonData = """query GetAxieTransferHistory($axieId: ID!, $from: Int!, $size: Int!) {
                  axie(axieId: $axieId) {
                    id
                    transferHistory(from: $from, size: $size) {
                      ...TransferRecords
                      __typename
                    }
                    ethereumTransferHistory(from: $from, size: $size) {
                     ...TransferRecords
                     __typename
                    }
                    __typename
                  }
                }

                fragment TransferRecords on TransferRecords {
                  total
                  results {
                    from
                    to
                    timestamp
                    txHash
                    withPrice
                    __typename
                  }
                  __typename
                }"""

        tableAxieTransactions = requests.post(url, json={"query": jsonData, "variables": params})
        if tableAxieTransactions.json()['data']['axie']['ethereumTransferHistory']['total'] != 0:
            for i in range(tableAxieTransactions.json()['data']['axie']['ethereumTransferHistory']['total']):
                success = None
                while success is None:
                    try:
                        now = datetime.now()
                        l01 = [now.strftime("%d/%m/%Y %H:%M:%S")]  # dateTime
                        l02 = [str(AxieId)]  # id
                        l03 = [str(tableAxieTransactions.json()['data']['axie']['ethereumTransferHistory']['results'][i]['withPrice'])]  # howMuch
                        l04 = [str(tableAxieTransactions.json()['data']['axie']['ethereumTransferHistory']['results'][i]['timestamp'])]  # timeStamp
                        l05 = [str(tableAxieTransactions.json()['data']['axie']['ethereumTransferHistory']['results'][i]['from'])]  # from
                        l06 = [str(tableAxieTransactions.json()['data']['axie']['ethereumTransferHistory']['results'][i]['to'])]  # to


                        success = 'Done'
                    except Exception as e:
                        print(e)
                        print('lol')
                        time.sleep(10)
                        pass
        else:
            pass

        if path.exists(fileName) != True:  # If the xlsx table doesn't exist yet, it creates it
            df = pandas.DataFrame({'dateTime': l01, 'id': l02, 'howMuch': l03, 'timeStamp': l04, 'from': l05, 'to': l06})
            df.to_excel(fileName, sheet_name='sheet1', index=False)

        df = pandas.DataFrame({'dateTime': l01, 'id': l02, 'howMuch': l03, 'timeStamp': l04, 'from': l05, 'to': l06})
        book = load_workbook(fileName)
        writer = pandas.ExcelWriter(fileName, engine='openpyxl')
        writer.book = book
        writer.sheets = {ws.title: ws for ws in book.worksheets}
        for sheetname in writer.sheets:
            df.to_excel(writer, sheet_name=sheetname, startrow=writer.sheets[sheetname].max_row,
                        index=False, header=False)
        writer.save()


        NewId += 1
    print(f'\033[92mDone!!!\033[0m')
